(function ($) {
    var widget = function () { };
    
    $.MyWidget = $.MyWidget || widget;
})(Zepto);