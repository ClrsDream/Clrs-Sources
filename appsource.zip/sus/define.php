<?php
/**
 * Created by JetBrains PhpStorm.
 * User: seaman
 * Date: 4/18/13
 * Time: 8:37 PM
 * To change this template use File | Settings | File Templates.
 */


//静态变量
define("PACKAGE_CSDN_SUS_DIR" , "/srv/suscsdn");

define("P_CSDN_IOS_VERSION", "0.9.3");   //iOS完整包版本
define("P_CSDN_IOS_URL", "http://itunes.apple.com/app/id534453594");   //iOS完整包地址
define("P_CSDN_IOS_FORCE", false);
define("P_CSDN_IOS_RELEASENOTE", "iOS iTunes升级 版本 1.1.1 中的新功能

<p>修复打不到巨鲸宝宝使用“XXL窝”的BUG。</p>
<p>新增多张深海地图，加入“挑战主题”，等你挑战！</p>
<p>修复其他BUGS。</p>
");

define("P_CSDN_IOS_WGT_VERSION", "0.9.3");   //iOS版本Wgt最新版本
define("P_CSDN_IOS_WGT_URL", "http://csdn.m3w.cn:9021/sus/file/B8B4BD.wgt");   //iOS版本Wgt最新版本 TODO 将来要废弃 做patch 版本
define("P_CSDN_IOS_WGT_FORCE", false);
define("P_CSDN_IOS_WGT_RELEASENOTE", "iOS WGT 升级 版本 1.1.1 中的新功能

<p>修复打不到巨鲸宝宝使用“XXL窝”的BUG。</p>
<p>新增多张深海地图，加入“挑战主题”，等你挑战！</p>
<p>修复其他BUGS。</p>
");



/*** ios 结束  ****/


define("P_CSDN_ANDROID_VERSION", "0.9.3");   //Android完整包版本
define("P_CSDN_ANDROID_URL", "http://m3w.cn/d/c.apk");   //Android完整包地址
define("P_CSDN_ANDROID_FORCE", false);
define("P_CSDN_ANDROID_RELEASENOTE", "Android 整包升级 版本 1.1.1 中的新功能

<p>修复打不到巨鲸宝宝使用“XXL窝”的BUG。</p>
<p>新增多张深海地图，加入“挑战主题”，等你挑战！</p>
<p>修复其他BUGS。</p>
");

define("P_CSDN_ANDROID_WGT_VERSION", "0.9.3");   //Android版本Wgt最新版本
define("P_CSDN_ANDROID_WGT_URL", "http://csdn.m3w.cn:9021/sus/file/B8B4BD.wgt");   //Android版本Wgt最新版本 TODO 将来要废弃 做patch 版本
define("P_CSDN_ANDROID_WGT_FORCE", false);
define("P_CSDN_ANDROID_WGT_RELEASENOTE", "Android WGT 升级 版本 1.1.1 中的新功能

<p>修复打不到巨鲸宝宝使用“XXL窝”的BUG。</p>
<p>新增多张深海地图，加入“挑战主题”，等你挑战！</p>
<p>修复其他BUGS。</p>
");

